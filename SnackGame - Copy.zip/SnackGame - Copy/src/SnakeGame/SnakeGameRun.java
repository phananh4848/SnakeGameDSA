package SnakeGame;

public class SnakeGameRun {
    public static void main(String[] args) {
        new ModeSelectionFrame();
    }
}

